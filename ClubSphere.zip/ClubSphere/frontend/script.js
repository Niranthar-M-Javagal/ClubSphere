// REGISTER
$(document).ready(function () {
  $("#registerForm").submit(async function (e) {
    e.preventDefault();

    const name = $("#regName").val();
    const email = $("#regEmail").val();
    const password = $("#regPassword").val();
    const role = $("#regRole").val();

    try {
      const res = await fetch("http://localhost:5000/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, role }),
      });

      const data = await res.json();

      if (res.ok) {
        $("#message").text("Registered successfully! You can now login.").css("color", "green");
        $("#registerForm")[0].reset();
      } else {
        $("#message").text(data.message || "Registration failed.").css("color", "red");
      }
    } catch (err) {
      console.error(err);
      $("#message").text("Server error during registration.").css("color", "red");
    }
  });

  // LOGIN
  $("#loginForm").submit(async function (e) {
    e.preventDefault();

    const email = $("#loginEmail").val();
    const password = $("#loginPassword").val();

    try {
      const res = await fetch("http://localhost:5000/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (res.ok) {
        localStorage.setItem("clubsphere_userId", data.id);
        localStorage.setItem("clubsphere_role", data.role);

        if (data.role === "student_head") window.location.href = "student.html";
        else if (data.role === "faculty_head") window.location.href = "faculty.html";
        else if (data.role === "facility_manager") window.location.href = "facility.html";
        else if (data.role === "principal") window.location.href = "principal.html";
      } else {
        $("#message").text(data.message || "Login failed.").css("color", "red");
      }
    } catch (err) {
      console.error(err);
      $("#message").text("Server error during login.").css("color", "red");
    }
  });
});

$(document).ready(function () {
  $('#loginForm').submit(function (e) {
    e.preventDefault(); // Prevent default form submit

    const email = $('#loginEmail').val();
    const password = $('#loginPassword').val();

    $.ajax({
      url: 'http://localhost:5000/api/users/login',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ email, password }),
      success: function (res) {
  const user = res.user;
  alert('Login successful!');
  sessionStorage.setItem('user', JSON.stringify(user));

  if (user.role === 'student_head') {
    window.location.href = 'student.html';
  } else if (user.role === 'faculty_head') {
    window.location.href = 'faculty.html';
  } else if (user.role === 'facility_manager') {
    window.location.href = 'facility.html';
  } else if (user.role === 'principal') {
    window.location.href = 'principal.html';
  } else {
    alert('Unknown role! Response: ' + JSON.stringify(user));
  }
}

,
      error: function (err) {
        $('#message').text('Login failed: ' + err.responseText);
      },
    });
  });
});
