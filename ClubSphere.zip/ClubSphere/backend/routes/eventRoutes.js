const express = require('express');
const eventController = require('../controllers/eventController');
const router = express.Router();
const db = require('../db'); // using mysql2/promise


router.post('/create', eventController.createEvent);
router.get('/user/:id', eventController.getUserEvents);

module.exports = router;


router.get('/pending', eventController.getPendingEvents);
router.put('/update-status', eventController.updateEventStatus);
router.get('/user/:id', eventController.getEventsByUser);
router.get('/all', eventController.getAllEvents);
router.post('/update-status', eventController.updateEventStatus); // ✅ THIS LINE
router.get('/by-status/:status', eventController.getEventsByStatus);

module.exports = router;

// eventRoutes.js

router.get('/all', async (req, res) => {
  try {
    const [events] = await db.query(`SELECT * FROM events'`);
    res.json(events);
  } catch (err) {
    console.error("🔥 ERROR in /api/events/all:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
