function loadAllEvents(containerId) {
  const API = "http://localhost:5000/api/events";

  $.get(`${API}/all`, function (events) {
    const allEventList = $(`#${containerId}`);
    allEventList.empty();

    if (events.length === 0) {
      allEventList.append("<p>No events found.</p>");
      return;
    }

    events.forEach(event => {
      const statusColor =
        event.status === "approved" ? "green" :
        event.status === "rejected" ? "red" :
        event.status === "faculty-approved" ? "#2980b9" :
        event.status === "pending" ? "#f39c12" : "gray";

      allEventList.append(`
        <div class="event-card">
          <strong>${event.title}</strong><br/>
          <em>${event.date} ${event.time} @ ${event.hall}</em><br/>
          <b>Requested by:</b> ${event.requested_by_name}<br/>
          <span class="badge" style="color:${statusColor}">Status: ${event.status}</span>
        </div>
      `);
    });
  });
}
