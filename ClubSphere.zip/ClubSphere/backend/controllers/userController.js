const db = require('../db');

// Register a new user
exports.registerUser = async (req, res) => {
  const { name, email, password, role } = req.body;

  const sql = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';

  try {
    await db.query(sql, [name, email, password, role]);
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error('Error registering user:', err);
    res.status(500).json({ message: 'Registration failed' });
  }
};

// Login
exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';

  try {
    const [results] = await db.query(sql, [email, password]);

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const user = results[0];
    res.status(200).json({ message: 'Login successful', user });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Login failed' });
  }
};
