const mysql = require('mysql2');
require('dotenv').config();

// Use promise wrapper
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
}).promise(); // <-- THIS is the important change

db.connect()
  .then(() => {
    console.log('Connected to MySQL DB');
  })
  .catch(err => {
    console.error('Database connection failed:', err.stack);
  });

module.exports = db;
