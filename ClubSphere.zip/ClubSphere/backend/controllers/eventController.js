const db = require('../db');

exports.createEvent = async (req, res) => {
  const { title, description, date, time, hall, userId } = req.body;
  const sql = `INSERT INTO events (title, description, date, time, hall, requested_by)
               VALUES (?, ?, ?, ?, ?, ?)`;
  try {
    await db.query(sql, [title, description, date, time, hall, userId]);
    res.status(201).json({ message: 'Event created successfully' });
  } catch (err) {
    console.error('Error creating event:', err);
    res.status(500).json({ message: 'Event creation failed' });
  }
};

exports.getUserEvents = async (req, res) => {
  const userId = req.params.id;
  const sql = `SELECT * FROM events WHERE requested_by = ?`;
  try {
    const [results] = await db.query(sql, [userId]);
    res.status(200).json(results);
  } catch (err) {
    console.error('Error fetching events:', err);
    res.status(500).json({ message: 'Failed to retrieve events' });
  }
};

exports.getPendingEvents = async (req, res) => {
  const sql = `SELECT events.*, users.name AS requested_by_name 
               FROM events 
               JOIN users ON events.requested_by = users.id 
               WHERE status = 'pending'`;
  try {
    const [results] = await db.query(sql);
    res.status(200).json(results);
  } catch (err) {
    console.error('Error fetching pending events:', err);
    res.status(500).json({ message: 'Error getting events' });
  }
};

exports.updateEventStatus = async (req, res) => {
  const { eventId, status } = req.body;
  const allowedStatuses = ['faculty-approved', 'approved', 'rejected'];

  if (!eventId || !allowedStatuses.includes(status)) {
    return res.status(400).json({ message: 'Invalid status or event ID' });
  }

  const sql = "UPDATE events SET status = ? WHERE id = ?";
  try {
    await db.query(sql, [status, eventId]);
    res.status(200).json({ message: 'Event status updated' });
  } catch (err) {
    console.error('Error updating event status:', err);
    res.status(500).json({ message: 'Failed to update event' });
  }
};

exports.getEventsByUser = async (req, res) => {
  const userId = req.params.id;
  const sql = 'SELECT * FROM events WHERE requested_by = ? ORDER BY id DESC';
  try {
    const [results] = await db.query(sql, [userId]);
    res.status(200).json(results);
  } catch (err) {
    console.error('Error fetching events:', err);
    res.status(500).json({ message: 'Error fetching events' });
  }
};

exports.getAllEvents = async (req, res) => {
  try {
    const [results] = await db.query(`
      SELECT e.id, e.title, CONCAT(e.date, 'T', e.time) AS start, e.hall, e.status,
             u.name AS requested_by_name
      FROM events e
      JOIN users u ON e.requested_by = u.id
      ORDER BY e.id DESC
    `);
    res.status(200).json(results);
  } catch (err) {
    console.error("Error fetching all events:", err);
    res.status(500).json({ message: "Error fetching events" });
  }
};




exports.getEventsByStatus = async (req, res) => {
  const status = req.params.status;
  const sql = "SELECT * FROM events WHERE status = ?";
  try {
    const [result] = await db.query(sql, [status]);
    res.status(200).json(result);
  } catch (err) {
    console.error('Error fetching events:', err);
    res.status(500).json({ message: 'Failed to fetch events' });
  }
};
